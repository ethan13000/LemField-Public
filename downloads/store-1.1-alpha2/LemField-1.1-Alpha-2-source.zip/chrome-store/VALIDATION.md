# Chrome Release 1 validation

Prepared November 14, 2026. Status: packaged submission candidate; not uploaded or approved.

## Completed

- 51 unique dependency-free suites pass via node scripts/verify-release1.cjs.
- All 40 source runtime JavaScript files pass Node syntax checks.
- Chrome regression coverage includes callback API error handling, Promise message routing, unrelated-message handling, synchronous service-worker handler registration, simulated cold restarts, offscreen creation concurrency, parser size limits and sender restrictions.
- The Chromium integration suite also passes against the exact generated chrome-1.0.1/extension files using MOX_CHROME_RELEASE_DIR, rather than only the working source.
- Expanded sync tests verify Chrome sync is off before opt-in, works after opt-in, stops after disabling, preserves the disabled state across restart and allows local imports while disabled. Existing Firefox consent tests still pass.
- Generated Chrome manifest: MV3, version 1.0.1, Chrome 120 minimum, service_worker background, storage/offscreen permissions, explicit packaged-script CSP, incognito disabled and no Firefox-only manifest fields.
- Build validates packaged JavaScript syntax and manifest, HTML and worker-import references. Every ZIP entry is decompressed and checked for CRC, length and SHA-256 equality against its source. Runtime package uses an explicit file allowlist; no tests, profiles, HARs, caches or development dependencies are included.
- Separate Chrome policy and popup copy; Chrome print sync requires explicit popup opt-in and supports disabling. The existing Firefox release artifacts are preserved.

## Environment limits and required follow-up

npm ci --ignore-scripts --no-audit --no-fund --fetch-retries=0 --fetch-timeout=10000 failed. The npm log records EACCES fetching registry.npmjs.org package archives; npm then reported "Exit handler never called!". jsdom and Playwright remain unavailable. The DOM/network suites, Playwright rendering and current dependency-advisory scanning have not completed. No passing live-browser result is claimed.

Before submission, run the exact build in a current desktop Chrome profile and complete STORE_SUBMISSION.md's smoke checklist. Still required: service-worker load/restart in Chrome, current live EDHREC/Scryfall requests, authenticated public/private Moxfield operations using a disposable owned deck, visual review, actual store screenshots, two-device Chrome account synchronization, and a physical duplex alignment test before large print jobs.

Complete the maintained support contact and publicly hosted HTTPS privacy-policy URL in the dashboard. The packaged local policy page does not replace that URL. Store listing, screenshots and privacy disclosures must match the tested build.

Desktop app inventory exposed Firefox but no open Chrome window, so no Chrome UI load test or listing screenshots were captured. The supplied icon is ready; actual Chrome screenshots remain required.

The extension relies on Moxfield's undocumented APIs/DOM and third-party card data, which can change. Simulated tests do not certify current live integrations. Large image/PDF exports remain memory-intensive; artwork stays local and is excluded from JSON backups and sync.

## Reproduce

From the working source folder:

    node scripts/verify-release1.cjs
    node scripts/prepare-chrome-release1.cjs

When registry access is available:

    npm ci
    npm test
    npm run test:browser

Browser checks require a compatible Playwright browser installation. Record any failures and fix/rebuild before submission.
